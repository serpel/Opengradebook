# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DatagridDemo::Application.config.secret_token = '5861b0dcec4df9455495edd1075d5b77d318eb24d6736a4c2d7c5ddb38c39b58f51361bbde64f1e2bd0d8dd984635761108c2febce9262115d391b7169e81d5b'
